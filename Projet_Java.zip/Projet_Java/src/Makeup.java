public class Makeup extends Produit{

    protected String couleur;
    public Makeup(String nom, double prix, int stock, String fournisseur) {
        super(nom,prix,stock,fournisseur);

    }

    public void ajoutStock(int nb) {
        stock += nb;
    }

    public void suppStock(int nb) {
        stock -= nb;
    }

    public String getCouleur() {
        return couleur;
    }
}
