//enregistrer le mot de passe

/*
import java.util.HashMap;                                   //hasmap permet de stocker des paires de clé-valeur permet de convertire une clé en indexe
import java.util.Map;


public class LoginManager {
    private Map<String, String> user = new HashMap<>();
    LoginButton loginButton =new LoginButton();

    public LoginManager() {
        this.user = loginButton.readUsersFromFile();
    }

    public boolean authenticate(String username, String password) {

        String savedPassword = user.get(username);
        return savedPassword != null && savedPassword.equals(password);
    }

}

*/









/*
public class LoginManager {
    private Map<String, String> user = new HashMap<>();                 //map pour stocker les noms et mdp

    public boolean valide(String username, String password){
        if(user.containsKey(username)){
            if(user.get(username).equals(password)){                    //le nom et le mdp correspondent
                System.out.println("Ravis de vous revoir " + username);
                return true;
            }else{
                System.out.println("Le mot de passe est incorrecte pour " + username);
                return false;
            }
        }else{
            //enregistrement de nouvel utilisateur

            System.out.println("BIENVENU "+username + " !!!");
            user.put(username,password);
            return true;
        }
    }
}
*/














   /* public boolean isValide(String username, String password){
        if(user.containsKey(username)){
            if(user.get(username).equals(password)){
                //System.out.println("Ravis de vous revoir " + username);
                return true;
            } else {
                //System.out.println("Le mot de passe est incorrect pour " + username);
                return false;
            }
        } else {
            //enregistrement du nouvel utilisateur
            //JLabel label = new JLabel("Bienvenue " + username + " !");
            //panel.add(label);
            //user.put(username, password);
            return true;
        }
    }

*/

    /*
    public void Userss(){
        user.put("Yeliz","AzerTy69@@");
        user.put("Ogan","pZSerr09Ty$@");
        user.put("Pierre","Admi12niTy$@");

    }


    public void showUsers(){
        Userss();
        System.out.println("Utilisateurs enregistrés: ");
        for(Map.Entry<String, String> entry : user.entrySet()){
            System.out.println("Username: " + entry.getKey() + ", Password: " + entry.getValue());
        }


    }

     */



