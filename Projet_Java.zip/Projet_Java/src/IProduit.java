//interface qu'on implemente pour définir les comportements communs a tous types de produits
/*
//ne sert a rien car je ne vais pas ajouter ou modifier les attributs et méthodes de cette classe
public interface IProduit {
    public String getNom();
    public double getPrix();
    public int getStock();
    public void ajoutStock(int nb);
    public void suppStock(int nb);

    public String getFournisseur();
}
*/