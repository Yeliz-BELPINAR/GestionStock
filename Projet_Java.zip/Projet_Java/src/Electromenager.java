public class Electromenager extends Produit{

    protected int puissance;

    public Electromenager(String nom, double prix, int stock, String fournisseur) {
        super(nom,prix,stock,fournisseur);

    }

    public void ajoutStock(int nb) {
        stock += nb;
    }

    public void suppStock(int nb) {
        stock -= nb;
    }

    public int getPuissance() {
        return puissance;
    }
}
