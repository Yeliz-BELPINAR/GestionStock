//MINI PROJET GESTION DE STOCK

//gérer l'ensemble des interfaces

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPage {

        private static void fenetre1() {

            //creation fenetre de connexion
            LoginFarme loginFrame = new LoginFarme();

            //création d'instance pour l'utilisateur
            PasswordPanel passwordPanel = new PasswordPanel();
            UsernamePanel usernamePanel = new UsernamePanel();
            // création du boutton connexion
            LoginButton loginButton = new LoginButton(usernamePanel.usernameField, passwordPanel.passwordField, loginFrame);            //field pour le text ecrit en zone de texte
           // loginFrame.setVisible(true); // Affichage de la fenêtre
            // création du bouton Supprimer
            JButton deleteButton = new JButton("DELETE USER");

            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String username = JOptionPane.showInputDialog(loginFrame, "Entrez le nom d'utilisateur à supprimer:");
                    if (username != null && !username.isEmpty()) {
                        loginButton.suppUsersFromFile(username);
                        //loginButton.writeUsersToFile(loginButton.readUsersFromFile());      // en parametre on recupere la liste des utilisateurs apres la suppression
                        JOptionPane.showMessageDialog(loginFrame, "L'utilisateur " + username + " a été supprimé.");
                        //pour pouvoir recharger la page pour voir les utilisateur supp au lieu de rééxecuter
                        fenetre1();
                    }
                }
            });

            //afficher les utilisateurs existant dans le fichier
            LoginButton loginButton1=new LoginButton();
            System.out.println(loginButton1.readUsersFromFile());


            //creation des panneaux pour placer les elements de l'interface
            JPanel buttonPanel = new JPanel(new BorderLayout());
            JPanel loginPanel = new JPanel(new GridLayout(2, 1, 0, 10));
            JPanel contentPanel = new JPanel(new BorderLayout());


            //ajout des éléments d'interface, le bouton au centre avec des espaces a droit et gauche de 50 pixel
            buttonPanel.add(loginButton, BorderLayout.NORTH);
            buttonPanel.add(deleteButton, BorderLayout.SOUTH);
            buttonPanel.add(Box.createHorizontalStrut(50), BorderLayout.WEST);
            buttonPanel.add(Box.createHorizontalStrut(50), BorderLayout.EAST);

            //Ajoue a loginPanel les noms et mdp
            loginPanel.add(usernamePanel);
            loginPanel.add(passwordPanel);


            //ajout sur l'interface a la fenetre principal et placement
            contentPanel.add(loginPanel, BorderLayout.CENTER);
            contentPanel.add(buttonPanel, BorderLayout.SOUTH);

            //Ajout panneau principal à la fenetre
            loginFrame.add(contentPanel);

            //rendre visible la fenetre
            loginFrame.setVisible(true);

        }


        //static :methode de class,  methode qui appartient à une classe plutot qu'a une instance de cette classe
        //elle peut être appelée sans avoir besoin d'instancier la classe, elle peut être appeler directement dans la class

        public static void main(String[] args) {
            fenetre1();
        }

}

