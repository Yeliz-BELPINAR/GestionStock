import java.util.ArrayList;

public class Stock {
    private static Stock instance;
    static {
        instance = new Stock();
    }
    private ArrayList<Produit> produits;

    private Stock() {
        this.produits = new ArrayList<Produit>();
    }

    public static Stock getInstance() {
        if (instance == null) {
            instance = new Stock();
        }
        return instance;
    }
}
