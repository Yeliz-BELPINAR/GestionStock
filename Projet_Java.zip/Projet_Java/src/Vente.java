import java.util.ArrayList;

public class Vente {

    // création de tableau qui contiendra tout les type de produits

    private ArrayList<Produit> produits = new ArrayList<>();

    public void ajoutProduit(Produit produit) {
        if (produit.getStock() > 0) {                           // Vérification de la disponibilité du produit
            produits.add(produit);
            produit.suppStock(1);                          // Décrémentation de la quantité en stock
        } else {
            System.out.println("Le produit " + produit.getNom() + " n'est pas disponible.");
        }
    }

    public void afficherStock() {
        System.out.println("Stock:");
        for (Produit produit : produits) {
            System.out.println(produit.getNom() + ": " + produit.getStock());
        }
    }


}
