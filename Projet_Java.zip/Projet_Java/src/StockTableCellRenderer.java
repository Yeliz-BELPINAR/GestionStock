import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

// Création d'un Renderer pour la coloration des cellules
public class StockTableCellRenderer extends DefaultTableCellRenderer {

    private final Color RED = new Color(255, 102, 102); // Définition de la couleur rouge

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        String stockValue = table.getModel().getValueAt(row, 2).toString(); // récupère la valeur du stock dans la colonne 3 (index 2)
        int stock = Integer.parseInt(stockValue);

        if (stock == 0) {
            cell.setBackground(Color.RED);
        } else {
            cell.setBackground(Color.WHITE);
        }

        return cell;
    }
}

