//Gérer la fenetre de connexion
import javax.swing.*;

public class LoginFarme extends JFrame {  //modifier le nom frame

    private ImageIcon backgroundImage;
    private JLabel backgroundLabel;
    public LoginFarme(){
        setTitle("CONNEXION A LA PLATEFORME");
        setSize(500,160);

        // Créer un objet JLabel pour afficher l'image de fond
        //JLabel background = new JLabel(new ImageIcon("marbreFond.png"));
        /*
        JLabel background = new JLabel(new ImageIcon(Objects.requireNonNull(LoginFarme.class.getResource("marbreFond.png"))));
        backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, getWidth(), getHeight());
        add(backgroundLabel);

        // Réglez les dimensions et la position du JLabel pour remplir toute la fenêtre
        background.setPreferredSize(new Dimension(0, 15));
        background.setBounds(0, 0, 500, 125);



        // Ajoutez le JLabel à la fenêtre en arrière-plan
        getContentPane().add(background);

         */

        setLocationRelativeTo(null);                //positionner les composants de maniere absolu par rapport a l'image de fond

    }

    /*public void showLoginFrame_deux() {
        LoginFrame_deux loginFrame_deux = new LoginFrame_deux();
        loginFrame_deux.setVisible(true);
    }*/

}




