import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ShowTabStock {



}





  /*
        private List<Produit> produits;  // les produits sont stocker dans une liste produits, on utilisera ses données en ajoutant dans le tableau multidimentionnel

        //initialise une instance de classe en chargeant le liste de produits depuis un fichier
        public ShowTabStock() throws IOException {
            produits = ListProduits("tabStock.txt"); // charge la liste de produits depuis le fichier
        }

        public void afficherStock() {
            // Création des colonnes du tableau
            String[] columns = {"Type", "Nom", "Prix", "Fournisseur", "Stock", "Info supplémentaire"};

            // pour pouvoir utiliser un tableau dynamique on peut utiliser une liste, modifier la taille
            // Création des données du tableau multidimentionnel qui a une taille par rapport au nb de produit
            Object[][] data = new Object[produits.size()][6];

            for (int i = 0; i < produits.size(); i++) {

                Produit produit = produits.get(i);

                String type = produit.getClass().getSimpleName();  //getClass() :récupère la class du type de produit, getSimpleName(): récupère le nom du type

                String nom = produit.getNom();
                double prix = produit.getPrix();
                String fournisseur = produit.getFournisseur();
                int stock = produit.getStock();

                String infoSupp = "";

                switch(type) {

                    case "Alimentaire":

                        Alimentaire ali = (Alimentaire) produit;
                        infoSupp = "Date d'expiration: " + ali.getDateExpiration();
                        break;

                    case "Makeup":
                        MakeUp makeup = (MakeUp) produit;
                        infoSupp = "Couleur: " + makeup.getCouleur();
                        break;

                    case "Electromenager":
                        Electromenager elec = (Electromenager) produit;
                        infoSupp = "Puissance: " + elec.getPuissance();
                        break;

                    default:
                        infoSupp = "Aucune information supplémentaire disponible";
                }

                data[i] = new Object[]{type, nom, prix, fournisseur, stock, infoSupp};
            }

            // Création de la table avec les données et les colonnes
            JTable table = new JTable(data, columns);

            // Ajout de la table à une JScrollPane pour permettre le scrolling
            JScrollPane scrollPane = new JScrollPane(table);

            // Création d'une nouvelle fenêtre pour afficher la table
            JFrame tableFrame = new JFrame("Stock");
            tableFrame.add(scrollPane);
            tableFrame.pack();                          //s'adapte a la taille par rapport à son contenue
            tableFrame.setLocationRelativeTo(null);
            tableFrame.setVisible(true);
        }


        public static List<Produit>  ListProduits(String filename) throws IOException {

            List<Produit> produits = new ArrayList<>();

            //Pour pouvoir lire à partir d'un fichier
            BufferedReader br = new BufferedReader(new FileReader(filename));

            String line;

            while ((line = br.readLine()) != null) {

                String[] fields = line.split(",");          //chaque mot est séparer par une virgule [0] correspond au premier mot avant la virgule

                String nom = fields[0];
                double prix = Double.parseDouble(fields[1]);
                int stock = Integer.parseInt(fields[2]);
                String fournisseur = fields[3];
                Produit produit = new Produit(nom, prix, stock, fournisseur);
                produits.add(produit);
            }
            br.close();
            return produits;
        }

        public void ajouterProduit(Produit produit) {
            produits.add(produit);
        }

    public static void sauvegarderListeProduits(List<Produit> listeProduits, String nomFichier) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nomFichier))) {
            // Pour chaque produit dans la liste, écrivez une ligne au format "nom,prix,stock,fournisseur"
            for (Produit produit : listeProduits) {
                writer.write(produit.getNom() + "," + produit.getPrix() + "," + produit.getStock()
                        + "," + produit.getFournisseur());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void sauvegarderListeProduits(List<Produit> listeProduits, String nomFichier) {
        // Obtenez la liste des produits à partir du fichier existant
        List<Produit> produitsExistant = Produit.getListProduitsFromFile(nomFichier);

        // Ajoutez le nouveau produit à cette liste
        produitsExistant.addAll(listeProduits);

        // Enregistrez la liste mise à jour dans le fichier
        Produit.sauvegarderListeProduits(produitsExistant, nomFichier);
    }
*/