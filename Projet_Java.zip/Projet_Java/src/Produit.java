import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Produit {
    protected String nom;            //nom du produit
    protected double prix;
    protected int stock;
    protected String fournisseur;
    protected static String type;

    public Produit(String nom, double prix, int stock, String fournisseur) {
        this.nom = nom;
        this.prix = prix;
        this.stock = stock;
        this.fournisseur = fournisseur;
    }

    public static String getType() {
        return type;
    }
    public static void saveToFile(ArrayList<Produit> produits, File file) throws IOException {
        FileWriter writer = new FileWriter(file,true);
        for (Produit produit : produits) {
            if (produit instanceof Electromenager) {
                writer.write("Electromenager/");
            } else if (produit instanceof Alimentaire) {
                writer.write("Alimentaire/");
            } else if (produit instanceof Makeup) {
                writer.write("Makeup/");
            }
            // writer.write("/");
            writer.write(produit.getNom() + "/");
            writer.write(produit.getPrix() + "/");
            writer.write(produit.getStock() + "/");
            writer.write(produit.getFournisseur() + "\n");
        }

        writer.close();
    }

    public static ArrayList<Produit> loadFromFile(File file) throws IOException {
        ArrayList<Produit> listeProduits = new ArrayList<>();
        Scanner scanner = new Scanner(file);

        while (scanner.hasNextLine()) {
            String[] produitData = scanner.nextLine().split("/");

            if (produitData.length == 5) {
                String type = produitData[0];
                String nom = produitData[1];
                double prix = Double.parseDouble(produitData[2]);
                int stock = Integer.parseInt(produitData[3]);
                String fournisseur = produitData[4];

                if (type.equals("Electromenager")) {
                    listeProduits.add(new Electromenager(nom, prix, stock, fournisseur));
                } else if (type.equals("Alimentaire")) {
                    listeProduits.add(new Alimentaire(nom, prix, stock, fournisseur));
                } else if (type.equals("MakeUp")) {
                    listeProduits.add(new Makeup(nom, prix, stock, fournisseur));
                } else {
                    throw new RuntimeException("Type de produit inconnu: " + type);
                }
            }
        }
        scanner.close();
        return listeProduits;
    }

    public void setStock(int newStock) {
        this.stock = newStock;
    }

    public int getStock() {

        return stock;
    }

    public void ajoutStock(int nb) {

        stock += nb;
    }

    public void suppStock(int nb) {

        stock -= nb;
    }

    // recuperer la valeur
    public String getNom() {

        return nom;
    }

    // modifier la valeur
    public void setNom(String nom) {

        this.nom = nom;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {

        this.prix = prix;
    }

    public String getFournisseur() {
        return fournisseur;
    }

    public void setFournisseur(String fournisseur) {
        this.fournisseur = fournisseur;
    }

}