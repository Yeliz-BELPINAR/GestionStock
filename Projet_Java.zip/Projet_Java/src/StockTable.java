import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class StockTable extends JTable {
    private static final String[] COLUMN_NAMES = {"TYPE","NOM", "PRIX (en $)", "QUANTITE", "FOURNISSEUR"};

    public StockTable(Object[][] data) {
        super(new DefaultTableModel(data, COLUMN_NAMES));
        setAutoCreateRowSorter(true);
        setFillsViewportHeight(true);
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    public Object[][] getData() {
        DefaultTableModel model = (DefaultTableModel) getModel();
        int rowCount = model.getRowCount();
        int columnCount = model.getColumnCount();
        Object[][] data = new Object[rowCount][columnCount];
        for (int row = 0; row < rowCount; row++) {
            for (int column = 0; column < columnCount; column++) {
                data[row][column] = model.getValueAt(row, column);
            }
        }
        return data;
    }
    public void clearTable() {
        int rowCount = getRowCount();
        int colCount = getColumnCount();
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < colCount; j++) {
                setValueAt(null, i, j); // Efface la valeur à la position (i, j)
            }
        }
    }

}
