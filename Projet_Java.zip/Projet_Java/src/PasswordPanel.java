//gérer le champ de saisie du mot de passe

import javax.swing.*;
import java.awt.*;

public class PasswordPanel extends JPanel {

    public JPasswordField  passwordField;
    public PasswordPanel(){
        setLayout(new GridLayout(1, 2, -10, 0));

        JLabel passwordLabel = new JLabel("Password :");
        passwordLabel.setForeground(new Color(130, 12, 100));
        add(passwordLabel);                                                         // == JPanel.add(passsLabel)

        passwordField = new JPasswordField(20);
        add(passwordField);
    }

    public String getPasswordField(){
        return new String(passwordField.getPassword());
    }
}