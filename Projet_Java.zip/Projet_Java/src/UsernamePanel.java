//gérer le champ de saisie du nom d'utilisateur

import javax.swing.*;
import java.awt.*;

public class UsernamePanel extends JPanel {
    public JTextField usernameField;
    public UsernamePanel(){
        setLayout(new GridLayout(1,1,1,90));                         //position avec Layout, la grille de la position gridLayoout

        JLabel usernameLabel = new JLabel("Username :");
        usernameLabel.setForeground(new Color(130, 12, 100));
        add(usernameLabel);                                                                 // on ajoute a la fenetre le label et sera visible qd on le rendra visible

        usernameField = new JTextField(20);
        usernameField.setBackground(new Color(200, 255, 25));
        usernameField.setPreferredSize(new Dimension(200, 0));
        add(usernameField);                                                                 // on ajoute a la fenetre la zone de texte et sera visible qd on le rendra visible

    }

   /* public String getUsernameField() {;
        return usernameField.getText();
    }*/

}
