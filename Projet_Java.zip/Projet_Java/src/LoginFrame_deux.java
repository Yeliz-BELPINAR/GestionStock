import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class LoginFrame_deux extends JFrame {

    private final ArrayList<Produit> listeProduits = new ArrayList<>(); // liste de tous les produits
    private final File file = new File("tabStock.txt");

    public LoginFrame_deux(){

        setTitle("GERER LE STOCK");
        setSize(300, 140);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);         //gere le comportement de fermeture de la fenetre


        JButton showTabB = new JButton("AFFICHER LE STOCK");
        JButton addProdB = new JButton("AJOUTER UN PRODUIT AU STOCK");
        JButton suppProdB = new JButton("SUPPRIMER UN PRODUIT DU STOCK");

        // creation panneau, avec disposition d'une boite verticale
        AtomicReference<JPanel> panel = new AtomicReference<>(new JPanel());
        panel.get().setLayout(new BoxLayout(panel.get(), BoxLayout.Y_AXIS));


        showTabB.setAlignmentX(Component.CENTER_ALIGNMENT);
        addProdB.setAlignmentX(Component.CENTER_ALIGNMENT);
        suppProdB.setAlignmentX(Component.CENTER_ALIGNMENT);

        //ajout des bouttons au panneau
        panel.get().add(showTabB);
        panel.get().add(addProdB);
        panel.get().add(suppProdB);

        //ajout du panneau a la fenetre
        add(panel.get());

        showTabB.addActionListener(e -> {

            JFrame frame = new JFrame("Tableau des produits");
            frame.setSize(500, 500);
            frame.setLocationRelativeTo(null);
            String[][] dataa;
            try {
                dataa = readDataFromFile(file);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(LoginFrame_deux.this, "Erreur lors de la lecture du fichier : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }
            StockTable stockTable = new StockTable(dataa);
            // Application du Renderer au tableau
            stockTable.setDefaultRenderer(Object.class, new StockTableCellRenderer());
            JScrollPane scrollPane = new JScrollPane(stockTable);
            frame.add(scrollPane);

            JButton clearButton = new JButton("Effacer le tableau");
            clearButton.addActionListener(e5 -> {
                try {
                    FileWriter fileWriter = new FileWriter(file);
                    fileWriter.write("");
                    fileWriter.close();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(LoginFrame_deux.this, "Erreur lors de l'écriture du fichier : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                stockTable.clearTable(); // Appel à la méthode "clearTable()" de votre classe StockTable

            });

            frame.add(clearButton, BorderLayout.SOUTH);

            frame.setVisible(true);
        });

        addProdB.addActionListener(e2 -> {
            // création de la fenêtre de dialogue pour saisir les informations du produit
            JDialog addProdDialog = new JDialog(LoginFrame_deux.this, "Ajouter un produit au stock", true);
            addProdDialog.setSize(400, 300);
            addProdDialog.setLocationRelativeTo(null);

            // création des labels et des champs de saisie
            JLabel typeLabel = new JLabel("Type:");
            JComboBox<String> typeComboBox = new JComboBox<>(new String[]{"Electromenager", "Alimentaire", "Makeup"});
            JLabel nomLabel = new JLabel("Nom:");
            JTextField nomTextField = new JTextField();
            JLabel prixLabel = new JLabel("Prix ($):");
            JTextField prixTextField = new JTextField();
            JLabel stockLabel = new JLabel("Stock:");
            JTextField stockTextField = new JTextField();
            JLabel fournisseurLabel = new JLabel("Fournisseur:");
            JTextField fournisseurTextField = new JTextField();

            // création du bouton pour ajouter le produit
            JButton addProdButton = new JButton("Ajouter");

            // création du panneau pour les composants de saisie et de bouton
            JPanel addProdPanel = new JPanel();
            addProdPanel.setLayout(new GridLayout(6, 2));
            addProdPanel.add(typeLabel);
            addProdPanel.add(typeComboBox);
            addProdPanel.add(nomLabel);
            addProdPanel.add(nomTextField);
            addProdPanel.add(prixLabel);
            addProdPanel.add(prixTextField);
            addProdPanel.add(stockLabel);
            addProdPanel.add(stockTextField);
            addProdPanel.add(fournisseurLabel);
            addProdPanel.add(fournisseurTextField);
            addProdPanel.add(addProdButton);

            // ajout du panneau à la fenêtre de dialogue
            addProdDialog.add(addProdPanel);

            // action à effectuer lorsque le bouton d'ajout est cliqué
            addProdButton.addActionListener(e -> {
                // création d'un nouveau produit avec les informations saisies
                String type = (String) typeComboBox.getSelectedItem();
                String nom = nomTextField.getText();
                double prix = Double.parseDouble(prixTextField.getText());
                int stock = Integer.parseInt(stockTextField.getText());
                String fournisseur = fournisseurTextField.getText();
                Produit produit;
                assert type != null;
                if (!Objects.equals(type, "Electromenager")) {
                    if (type.equals("Alimentaire")) {
                        produit = new Alimentaire(nom, prix, stock, fournisseur);
                    } else {
                        produit = new Makeup(nom, prix, stock, fournisseur);
                    }
                } else {
                    produit = new Electromenager(nom, prix, stock, fournisseur);
                }
                // Ajout du nouveau produit à la liste
                listeProduits.add(produit);

                try {

                    Produit.saveToFile(listeProduits, file); // sauvegarde des données dans le fichier
                    removeDuplicatesFromFile(file); // Supprimer les doublons dans le fichier

                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                // fermeture de la fenêtre de dialogue
                addProdDialog.dispose();
            });

            // affichage de la fenêtre de dialogue
            addProdDialog.setVisible(true);
        });

        suppProdB.addActionListener(e3 -> {
            try {
                ArrayList<Produit> listeProduits = Produit.loadFromFile(file);

                // création d'un HashSet pour stocker les noms des produits sans doublons
                HashSet<String> nomsProduits = new HashSet<>();
                for (Produit produit : listeProduits) {
                    //nomsProduits.add(produit.getNom());
                    if (produit.getStock() > 0) {       //affiche pas dans la liste du truc qui déroule quand c a 0
                        nomsProduits.add(produit.getNom());
                    }
                }

                // création d'un tableau contenant les noms de produits
               // String[] nomsProduitsArray = new String[nomsProduits.size()];
               // nomsProduits.toArray(nomsProduitsArray);

                // création d'un tableau contenant les noms de produits
                String[] nomsProduitsArray = nomsProduits.toArray(new String[0]);

                // affichage de la boîte de dialogue avec la liste déroulante
                String nomProduit = (String) JOptionPane.showInputDialog(null, "Choisissez un produit à supprimer :",
                        "Supprimer un produit", JOptionPane.QUESTION_MESSAGE, null, nomsProduitsArray, nomsProduitsArray[0]);

                // recherche du produit correspondant au nom sélectionné
                Produit produitSelectionne = null;
                int indexProduitSelectionne = -1;
                for (int i = 0; i < listeProduits.size(); i++) {
                    if (listeProduits.get(i).getNom().equals(nomProduit)) {
                        produitSelectionne = listeProduits.get(i);
                        indexProduitSelectionne = i;
                        break;
                    }
                }

                int stockInitial = produitSelectionne.getStock();

                // demande du nombre d'articles à supprimer
                int quantiteASupprimer = 0;

                String input = JOptionPane.showInputDialog("Combien d'articles souhaitez-vous supprimer du stock ?");
                try {
                    quantiteASupprimer = Integer.parseInt(input);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Veuillez entrer un nombre valide pour la quantité à supprimer.");
                }

                if (quantiteASupprimer > stockInitial) {
                    JOptionPane.showMessageDialog(null, "Il ne reste que " + stockInitial + " articles de ce produit. Veuillez entrer un nombre valide.");
                }

                // mise à jour du stock du produit sélectionné
                int nouveauStock = stockInitial - quantiteASupprimer;
                produitSelectionne.setStock(nouveauStock);

                if (nouveauStock == 0) {
                    // Si le stock est à 0, afficher le produit en rouge
                    UIManager.put("OptionPane.messageForeground", Color.RED);
                    JOptionPane.showMessageDialog(null, "Attention, le stock de ce produit est maintenant à 0 !");
                    UIManager.put("OptionPane.messageForeground", Color.BLACK);
                }

                // remplacer le produit d'origine par le produit mis à jour dans la liste
                listeProduits.set(indexProduitSelectionne, produitSelectionne);

                // enregistrement des modifications dans le fichier
                Produit.saveToFile(listeProduits, file);

                // supprimer les produits dupliqués
                supprimerProduitsDupliques(file);


                JOptionPane.showMessageDialog(null, "Le stock a été mis à jour pour " + nomProduit);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Erreur lors de la lecture du fichier de stock : " + ex.getMessage());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Veuillez entrer un nombre valide pour la quantité à supprimer.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Une erreur est survenue : " + ex.getMessage());
            }

        });
    }
    public String[][] readDataFromFile(File file) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        ArrayList<String[]> data = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("/");
            data.add(parts);
        }
        reader.close();
        return data.toArray(new String[0][0]);
    }

    public static void removeDuplicatesFromFile(File file) throws IOException {
        // Lire les données du fichier dans une liste
        java.util.List<String> lines = Files.readAllLines(file.toPath());

        // Supprimer les doublons dans la liste
        List<String> uniqueLines = new ArrayList<>(new HashSet<>(lines));

        // Écrire les données modifiées dans le fichier
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String line : uniqueLines) {
                writer.write(line);
                writer.newLine();
            }
        }
    }

    private static void supprimerProduitsDupliques(File file) throws IOException {
        ArrayList<Produit> listeProduits = Produit.loadFromFile(file);

        for (int i = 0; i < listeProduits.size() - 1; i++) {
            Produit produit1 = listeProduits.get(i);

            for (int j = i + 1; j < listeProduits.size(); j++) {
                Produit produit2 = listeProduits.get(j);

                if (produit1.getNom().equals(produit2.getNom()) && produit1.getFournisseur().equals(produit2.getFournisseur())) {
                    if (produit1.getStock() < produit2.getStock()) {
                        listeProduits.remove(j);
                        j--;
                    } else {
                        listeProduits.remove(i);
                        i--;
                        break;
                    }
                }
            }
        }

        Produit.saveToFile(listeProduits, file);
        FileWriter writer = new FileWriter(file);
        for (Produit produit : listeProduits) {
            if (produit instanceof Electromenager) {
                writer.write("Electromenager/");
            } else if (produit instanceof Alimentaire) {
                writer.write("Alimentaire/");
            } else if (produit instanceof Makeup) {
                writer.write("Makeup/");
            }
            writer.write(produit.getNom() + "/");
            writer.write(produit.getPrix() + "/");
            writer.write(produit.getStock() + "/");
            writer.write(produit.getFournisseur() + "\n");
        }
        writer.close();

    }



}