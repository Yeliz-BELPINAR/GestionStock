//gérer le bouton de connexion

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class LoginButton extends JButton {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JFrame loginFarme;
    private Map<String, String> users;

    public void writeUsersToFile(Map<String,String> users) {

        try (PrintWriter writer = new PrintWriter(new File("users.txt"))) {
            for (Map.Entry<String, String> entry : users.entrySet()) {
                writer.println(entry.getKey() + " : " + entry.getValue());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }


    public Map<String, String> readUsersFromFile() {

        Map<String, String> users = new HashMap<>();

        //on stock le nouveau utilisateur dans un fichier texte (sinon base de donnée)

        // les blocs de try-catch permet de détecter des erreur et gerer, si ya un pb il fait ce qu'il y a dans catch
        try (Scanner scanner = new Scanner(new File("users.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(" : ");
                users.put(parts[0], parts[1]);
            }
        } catch (FileNotFoundException e) {

            //System.out.println("Fichier non existant");
            e.printStackTrace();

        }
        return users;
    }

    //elle ne retourne pas de map elle supprime juste donc on met void

    public void suppUsersFromFile(String username){
        Map<String,String> users= readUsersFromFile();
        //while(!readUsersFromFile().isEmpty()){        on ne peut pas faire ca car a chaque appel on va créer une instance et a chaque fois remove supp l'element de cette instance, donc ons sera pas dans le mm Map la boucle sera infini
        if(users.containsKey(username)){
            users.remove(username);
        }
       writeUsersToFile(users);
    }

    public LoginButton(JTextField usernameField, JPasswordField passwordField, JFrame loginFarme){
        super("LOGIN");                                                                                     //loginButton hérite de la class JButton, on appl le constructeur de la classe Jbutton avec le texte Login comme ca il va créer un bouton avec ce texte
        setForeground(new Color(25, 200, 87));

        this.usernameField = usernameField;
        this.passwordField =passwordField;
        this.loginFarme = loginFarme;
        this.users = readUsersFromFile();


        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
                String username = usernameField.getText();                                                         //on récupere le nom saisie dans la zone de texte
                String password = passwordField.getText();


                if (password.matches(regex) && !password.isEmpty()) {                                      //on peut mettre en base de donnée des mot de passe et comparer si elle existe ou pas

                    if (users.containsKey(username)) {
                        String savedPassword = users.get(username);
                        if (savedPassword.equals(password)) {

                            JOptionPane.showMessageDialog(loginFarme, "Ravis de vous revoir " + username + " !!", "Message", JOptionPane.INFORMATION_MESSAGE);
                            loginFarme.dispose();
                            //ouverture deuxieme fenetre
                            LoginFrame_deux loginFrameDeux = new LoginFrame_deux();
                            // Affichez la deuxième fenêtre
                            loginFrameDeux.setVisible(true);

                        } else {
                            JOptionPane.showMessageDialog(loginFarme, "Le mot de passe ne correspond pas à l'utilisateur", "Message", JOptionPane.INFORMATION_MESSAGE);
                            //loginFarme.dispose();
                            passwordField.setText("");
                        }
                    } else {
                        JOptionPane.showMessageDialog(loginFarme, "Bienvenue " + username + " !!", "Message", JOptionPane.INFORMATION_MESSAGE);
                        loginFarme.dispose();
                        //ouverture deuxieme fenetre
                        LoginFrame_deux loginFrameDeux = new LoginFrame_deux();
                        // Affichez la deuxième fenêtre
                        loginFrameDeux.setVisible(true);
                        users.put(username,password);
                        writeUsersToFile(users);
                        System.out.println("\nVoici les membres : "+readUsersFromFile());
                    }
                    return;
                } else {
                    JOptionPane.showMessageDialog(loginFarme, "Incorrect password.Saisir au moins :" +
                                    "\n- 1 lettre majuscule\n- 1 lettre minuscule\n- 1 chiffre\n- 1 caractère spécial " +
                                    "(Parmis :@$!%*?&)\n- une longueur minimale de 8\nPlease try again.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    passwordField.setText("");
                }
                 }
            });
        }
        public LoginButton(){
        }


    }